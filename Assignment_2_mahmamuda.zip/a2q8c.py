import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

x, y, z = sp.symbols('x y z')
F = [x**3, y**3, z**2]
# Compute divergence
div_F = sp.diff(F[0], x) + sp.diff(F[1], y) + sp.diff(F[2], z)
print("Divergence of F:", div_F)
# Convert to cylindrical coordinates
r, theta, z = sp.symbols('r theta z')
div_F_cyl = div_F.subs({x: r*sp.cos(theta), y: r*sp.sin(theta)})
# Set up volume integral over the cylinder x² + y² ≤ 9, 0 ≤ z ≤ 2
flux = sp.integrate(sp.integrate(sp.integrate(div_F_cyl * r, (r, 0, 3)), (theta, 0, 2*sp.pi)), (z, 0, 2))
print("Outward flux of F using Divergence Theorem:", flux)

# Visualization of the enclosed cylindrical region
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(111, projection='3d')
# Cylinder parameters
theta_vals = np.linspace(0, 2*np.pi, 100)
z_vals = np.linspace(0, 2, 50)
theta_vals, z_vals = np.meshgrid(theta_vals, z_vals)
r_vals = 3  # Radius of cylinder
# Convert to Cartesian coordinates
X = r_vals * np.cos(theta_vals)
Y = r_vals * np.sin(theta_vals)
Z = z_vals

ax.plot_surface(X, Y, Z, color='c', alpha=0.6)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
ax.set_title("Enclosed Cylindrical Region")
plt.show()