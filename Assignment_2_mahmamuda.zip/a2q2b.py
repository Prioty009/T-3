import numpy as np
import sympy as sp
import matplotlib.pyplot as plt

# Symbolic definitions
s, t = sp.symbols('s t')
r_t = sp.Matrix([sp.cos(t), sp.sin(t), t])
r_prime = r_t.diff(t)
r_prime_norm = sp.sqrt(sum(comp**2 for comp in r_prime))  # sqrt(2)
s_expr = sp.integrate(r_prime_norm, (t, 0, t))            # s = sqrt(2)*t
t_expr = sp.solve(sp.Eq(s, s_expr), t)[0]          # t = s / sqrt(2)

# Arc length parameterization
r_s = r_t.subs(t, t_expr)
r_s = sp.simplify(r_s)

print("Arc length parameterization r(s):")
sp.pprint(r_s)

# Evaluate start and end point
s_final = 10
start = r_t.subs(t, 0)
end = r_s.subs(s, s_final)
# Numerical helix curve
t_vals = np.linspace(0, float(end[2]) + 2, 200)
x_vals, y_vals, z_vals = np.cos(t_vals), np.sin(t_vals), t_vals

# Plotting
fig = plt.figure(figsize=(8, 8))
ax = fig.add_subplot(111, projection='3d')
ax.plot(x_vals, y_vals, z_vals, label='Helix')
# Start and end points
ax.scatter(float(start[0]), float(start[1]), float(start[2]), color='r', s=100, label='Start (1,0,0)')
ax.scatter(float(end[0]), float(end[1]), float(end[2]), color='g', s=100, label='End after s=10')
# Labels
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
ax.legend()
plt.title('Helix with Arc Length Parameterization')
plt.show()

# Final position
print("Final position after walking 10 units:")
sp.pprint(end)