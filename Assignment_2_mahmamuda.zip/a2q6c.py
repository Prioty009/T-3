import sympy as sp
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import dblquad
from mpl_toolkits.mplot3d import Axes3D

x, y ,r,theta= sp.symbols('x y r theta')
z=4-x**2-y**2                        #integrating over a disk of radius 1 centered at (1, 0).
volume=sp.integrate(sp.integrate(z.subs({x:r*sp.cos(theta)+1,y:r*sp.sin(theta)})*r,(r,0,1)),(theta,0,2*sp.pi))
print(f'volume:',volume)   #The extra r comes from the Jacobian determinant when converting to polar coordinates
# -----------------Visualization---------------------------
X = np.linspace(0, 2, 100)
Y = np.linspace(-1, 1, 100)
X, Y = np.meshgrid(X, Y)
Z = 4 - X**2 - Y**2
fig = plt.figure(figsize=(12, 7))
ax = fig.add_subplot(111, projection='3d')
surf = ax.plot_surface(X, Y, Z, cmap='viridis')
plt.title('Paraboloid z = 4 - x^2 - y^2 inside the cylinder')
fig.colorbar(surf)
# Cylinder visualization
theta = np.linspace(0, 2 * np.pi, 100)
x_cyl = 1 + np.cos(theta)
y_cyl = np.sin(theta)
z_cyl = np.linspace(0, 4, 100)
X_cyl, Z_cyl = np.meshgrid(x_cyl, z_cyl)
Y_cyl, _ = np.meshgrid(y_cyl, z_cyl)
ax.plot_surface(X_cyl, Y_cyl, Z_cyl, color='orange', alpha=0.6)
plt.show()