import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

x, y, z, lamb = sp.symbols('x y z lamb')
T = 8*x**2 + 4*y*z - 16*z + 600
g = 4*x**2 + y**2 + 4*z**2 - 16
grad_T = sp.Matrix([sp.diff(T, var) for var in (x, y, z)])
grad_g = sp.Matrix([sp.diff(g, var) for var in (x, y, z)])
equations = [grad_T[i] - lamb * grad_g[i] for i in range(3)] + [g]
solutions = sp.solve(equations, (x, y, z, lamb), dict=True)
max_temp = -np.inf
hottest_point = None
for sol in solutions:
    temp = T.subs(sol)
    if temp > max_temp:
        max_temp = temp
        hottest_point = sol

print("Hottest Point:", hottest_point)
print("Maximum Temperature:", max_temp)

# Check constraint  #no need for this part to show
check = g.subs(hottest_point)
print("Constraint check (should be 0):", check.simplify())
print("Is on surface?", np.isclose(float(check), 0))

#Plotting
hottest_x = float(hottest_point[x])
hottest_y = float(hottest_point[y])
hottest_z = float(hottest_point[z])
# Ellipsoid surface
u = np.linspace(0, 2*np.pi, 50)
v = np.linspace(0, np.pi, 25)
U, V = np.meshgrid(u, v)
# Correct parametric ellipsoid (a=2, b=4, c=2)
X = 2 * np.cos(U) * np.sin(V)
Y = 4 * np.sin(U) * np.sin(V)
Z = 2 * np.cos(V)
# Plot
fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z, color='lightblue', alpha=0.7)
ax.scatter(hottest_x, hottest_y, hottest_z, color='red', s=100, label='Hottest Point')
ax.text(hottest_x, hottest_y, hottest_z, "Max", color='black')
ax.set_xlabel('X-axis')
ax.set_ylabel('Y-axis')
ax.set_zlabel('Z-axis')
ax.set_title('Space Probe Temperature Analysis')
ax.legend()
plt.show()