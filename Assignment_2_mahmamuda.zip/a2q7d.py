import numpy as np
import sympy as sp
import matplotlib.pyplot as plt

x, y = sp.symbols('x y')
f = sp.Matrix([sp.exp(y), x*sp.exp(y)])
p = f[0, 0]
q = f[1, 0]

# i) Check if force field is conservative
py = sp.diff(p, y)
qx = sp.diff(q, x)
if sp.simplify(py - qx) == 0:
    print('The force field is conservative on entire xy plane')
else:
    print('The force field is not conservative on entire xy plane')

# ii) Find potential function phi(x,y)
phi_partial = sp.integrate(p, x)  # Integrate P w.r.t x
C = sp.Function('C')(y)            # Unknown function of y
phi = phi_partial + C
dphi_dy = sp.diff(phi, y)          # Differentiate phi w.r.t y
eq = sp.Eq(dphi_dy, q)             # Equation dphi/dy = Q
C_prime = sp.simplify(sp.solve(eq, C.diff(y))[0]) # Solve for C'(y)
C_func = sp.integrate(C_prime, y)
phi = phi_partial + C_func
print('Potential function:')
sp.pprint(phi)

# iii) Compute work done from (1,0) to (-1,0)
start = {x: 1, y: 0}
end = {x: -1, y: 0}
phi_start = phi.subs(start)
phi_end = phi.subs(end)
work_done = phi_end - phi_start
print(f"Work done by the field: {work_done}")

# -------------- visualization ----------------------
# Define semicircular path from (1,0) to (-1,0)
theta = np.linspace(0, np.pi, 100)
x_vals = np.cos(theta)
y_vals = np.sin(theta)

# Create lambdified functions for numeric evaluation of Fx, Fy
Fx_func = sp.lambdify((x, y), p, 'numpy')
Fy_func = sp.lambdify((x, y), q, 'numpy')
X, Y = np.meshgrid(np.linspace(-1.5, 1.5, 20), np.linspace(-1, 1, 20))
# Evaluate vector field on grid
Fx = Fx_func(X, Y)
Fy = Fy_func(X, Y)

plt.figure(figsize=(8, 6))
plt.quiver(X, Y, Fx, Fy, color='blue', alpha=0.5, label='Force Field F(x, y)')
plt.plot(x_vals, y_vals, 'r--', label='Path C (semicircle)') # Plot semicircular path
# Add arrows along the path to indicate direction
arrow_idx = np.linspace(0, len(x_vals) - 2, 8).astype(int)
for i in arrow_idx:
    plt.annotate('', xy=(x_vals[i + 1], y_vals[i + 1]), xytext=(x_vals[i], y_vals[i]),
                 arrowprops=dict(arrowstyle='->', color='black'))

plt.scatter([1, -1], [0, 0], color='black')# Mark start and end points
plt.text(1, 0, '(1,0)', fontsize=12, verticalalignment='bottom')
plt.text(-1, 0, '(-1,0)', fontsize=12, verticalalignment='bottom')
plt.title('Force Field and Semicircular Path with Direction')
plt.legend()
plt.grid(True)
plt.show()