import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

x, y, z = sp.symbols('x y z')
F = [2*z, 3*x, 5*y]
curl_F = sp.Matrix([
    sp.diff(F[2], y) - sp.diff(F[1], z),
    sp.diff(F[0], z) - sp.diff(F[2], x),
    sp.diff(F[1], x) - sp.diff(F[0], y)
])
print("Curl of F:", curl_F)
# Surface integral over the paraboloid z = 4 - x^2 - y^2
r, theta = sp.symbols('r theta')
curl_F_cyl = curl_F.subs({x: r*sp.cos(theta), y: r*sp.sin(theta), z: 4 - r**2})
# Normal vector to the surface (upward orientation) is simply k-hat: (0,0,1)
flux = sp.integrate(sp.integrate(curl_F_cyl[2] * r, (r, 0, 2)), (theta, 0, 2*sp.pi))
print("Surface integral ∫∫ (curl F) ⋅ dS:", flux)
# Line integral along the circle x^2 + y^2 = 4
C_param = {x: 2*sp.cos(theta), y: 2*sp.sin(theta), z: 0}
F_C = sp.Matrix([F[i].subs(C_param) for i in range(3)])
dr_dt = sp.Matrix([
    sp.diff(C_param[x], theta), 
    sp.diff(C_param[y], theta),
    sp.diff(C_param[z], theta)
])
line_integral = sp.integrate(F_C.dot(dr_dt), (theta, 0, 2*sp.pi))
print("Line integral ∮ F ⋅ dr:", line_integral)
if flux==line_integral:
    print('Stoke''s theorem verified')
else:
    print('Stoke''s theorem not verified')
# -------------Visualization of the paraboloid--------------
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(111, projection='3d')
theta_vals = np.linspace(0, 2*np.pi, 100)
r_vals = np.linspace(0, 2, 50)
theta_vals, r_vals = np.meshgrid(theta_vals, r_vals)
Z = 4 - r_vals**2
X = r_vals * np.cos(theta_vals)
Y = r_vals * np.sin(theta_vals)

ax.plot_surface(X, Y, Z, color='c', alpha=0.6)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
ax.set_title("Surface σ: Paraboloid z = 4 - x² - y²")
plt.show()