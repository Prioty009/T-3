import sympy as sp
import numpy as np

t,x,y,z,X,Y,Z=sp.symbols('t x y z X Y Z')
#chain rule: dw/dt=dw/dx*dx/dt+dw/dy*dy/dt+dw/dz*dz/dt
w=sp.sqrt(X**2+Y**2+Z**2)
wx=w.diff(X)
wy=w.diff(Y)
wz=w.diff(Z)

x=sp.cos(t)
y=sp.sin(t)
z=sp.tan(t)
xt=x.diff(t)
yt=y.diff(t)
zt=z.diff(t)

wx_t = wx.subs({X: x, Y: y, Z: z})
wy_t = wy.subs({X: x, Y: y, Z: z})
wz_t = wz.subs({X: x, Y: y, Z: z})

chain_formula=wx_t*xt+wy_t*yt+wz_t*zt
print('dw/dt:\n')
sp.pprint(chain_formula)
chain_formula_np=sp.lambdify(t,chain_formula,modules='numpy')
derivative=chain_formula_np(np.pi/4)
print(f'at t=pi/4, dw/dt(pi/4=)',derivative)