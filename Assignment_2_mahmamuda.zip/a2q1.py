import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from sympy import symbols, sin, cos, tan, diff
#a)i)
print("First parametric equation")
t1=2
x1,y1,z1=np.log(t1),np.exp(-t1),t1^3
dx1,dy1,dz1=1/t1,-np.exp(t1),3*t1^2
print(f'x={x1}+{dx1}t')
print(f'y={y1}+{dy1}t')
print(f'z={z1}+{dz1}t')
#ii)
print("second parametric equation")
t1=1/3
x1,y1,z1=2*np.cos(np.pi*t1),2*np.sin(np.pi*t1),3*t1
dx1,dy1,dz1=-2*np.pi*np.sin(np.pi*t1),2*np.pi*np.cos(np.pi*t1),3
print(f'x={x1}+{dx1}t')
print(f'y={y1}+{dy1}t')
print(f'z={z1}+{dz1}t')
#(b)
n1=np.array([3,-6,-2])
n2=np.array([2,1,-2])
direction_vector=np.cross(n1,n2)
print("A vector parallel to the line inetersection:",direction_vector)
# (c)
#finding v and a as a function of theta
theta = symbols('theta')
r = sp.Matrix([3*theta, sin(theta), theta**2])
v = r.diff(theta)
a = v.diff(theta)
print("velocity:")
sp.pprint(v)
print("acceleration:")
sp.pprint(a)
#plotting theta vs t
t = sp.symbols('t')
r = sp.Matrix([3*t, sp.sin(t), t**2])
v = r.diff(t)      
a = v.diff(t)        
v_dot_a = v.dot(a)
v_mag = sp.sqrt(v.dot(v))
a_mag = sp.sqrt(a.dot(a))
cos_theta = v_dot_a / (v_mag * a_mag)  #angle=cos^(-1)((v.a)/|v||a|)
theta_expr = sp.acos(cos_theta)  # θ(t) in radians
theta_func = sp.lambdify(t, theta_expr, modules='numpy')#Convert to a numerical function
t_vals = np.linspace(-10, 10, 1000)
theta_vals = theta_func(t_vals)

plt.figure(figsize=(10, 5))
plt.plot(t_vals, theta_vals, color='purple')
plt.xlabel('t')
plt.ylabel('θ(t) [radians]')
plt.title('Angle θ(t) Between Velocity and Acceleration Vectors')
plt.grid(True)
plt.tight_layout()
plt.show()