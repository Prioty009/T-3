import numpy as np
import sympy as sp
from sympy import symbols,sin,cos,diff,exp
import matplotlib.pyplot as plt

t= sp.symbols('t')
r1 = sp.Matrix([sp.exp(t), sp.exp(t) * sp.cos(t), sp.exp(t) * sp.sin(t)])
r2 = sp.Matrix([2 * sp.cos(t), 3 * sp.sin(t), 0])

def compute_frenet_serret(r):
    r_prime = r.diff(t)
    r_pprime = r_prime.diff(t)
    r_ppprime = r_pprime.diff(t)
    norm_rp=sp.sqrt(r_prime.dot(r_prime))
    #norm_rpp=sp.sqrt(r_pprime.dot(r_pprime))
    #norm_rppp=sp.sqrt(r_ppprime.dot(r_ppprime))
    T = r_prime / norm_rp        #T=r'(t)/|r'(t)|
    T_prime=T.diff(t)
    norm_Tp=sp.sqrt(T_prime.dot(T_prime))
    N = T_prime / norm_Tp         #N=T'(t)/|T'(t)|
    B = T.cross(N)                       #B(t)=T(t)*N(t)
    kappa=norm_Tp/norm_rp  #K(t)=|T'(t)|/|r'(t)|
    crossing=r_prime.cross(r_pprime)
    norm_crossing=(sp.sqrt(crossing.dot(crossing)))**2
    tau = (r_prime.cross(r_pprime)).dot(r_ppprime) / norm_crossing
    #Taw=(r'*r'').r'''/|r'*r''|^2
    return T, N, B, kappa, tau

def results(name, T, N, B, kappa, tau):
    print(f'\n{name}')
    print('Tangent Vector T(t):')
    sp.pprint(T)
    print('\nNormal Vector N(t):')
    sp.pprint(N)
    print('\nBinormal Vector B(t):')
    sp.pprint(B)
    print('\nCurvature κ(t):')
    sp.pprint(kappa)
    print('\nTorsion τ(t):')
    sp.pprint(tau)
    print('\n' + '-'*50)

# Compute for both curves
T1, N1, B1, kappa1, tau1 = compute_frenet_serret(r1)
T2, N2, B2, kappa2, tau2 = compute_frenet_serret(r2)

# Display results using the function
results('(i) Curve 1: Exponential Helix', T1, N1, B1, kappa1, tau1)
results('(ii) Curve 1: Exponential Helix', T2, N2, B2, kappa2, tau2)

##plotting
t1=np.linspace(0,2*np.pi,100)
k1_np=sp.lambdify(t,kappa1,'numpy')
k2_np=sp.lambdify(t,kappa1,'numpy')
k1=k1_np(t1)
k2=k2_np(t1)
plt.plot(t1,k1,k2)
plt.xlabel('t')
plt.ylabel('Curvature')
plt.title('Curvature vs t')
plt.show()