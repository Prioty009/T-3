import sympy as sp  #need verification
import numpy as np
import matplotlib.pyplot as plt

rho, phi, theta = sp.symbols('rho phi theta')
# x = rho*sin(phi)*cos(theta), y = rho*sin(phi)*sin(theta), z = rho*cos(phi)  #rho=1(radius 1)
x_sph = rho * sp.sin(phi) * sp.cos(theta)# x^2 in spherical coordinates
jacobian = rho**2 * sp.sin(phi)# Jacobian for spherical coordinates: rho^2 * sin(phi)
x_squared = (x_sph)**2
surface_integral = sp.integrate(sp.integrate((x_squared * jacobian).subs(rho, 1), (phi, 0, sp.pi)), (theta, 0, 2*sp.pi))
print("(b) Surface integral over the sphere using spherical coordinates:", surface_integral) 

#-----------visualization-------------------
# Create a meshgrid for spherical coordinates
phi, theta = np.meshgrid(np.linspace(0, np.pi, 50), np.linspace(0, 2*np.pi, 50))
# Convert to Cartesian coordinates (unit sphere)
x = np.sin(phi) * np.cos(theta)
y = np.sin(phi) * np.sin(theta)
z = np.cos(phi)

fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(x, y, z, color='c', alpha=0.6)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
ax.set_title("Unit Sphere for Surface Integral Visualization")
plt.show()