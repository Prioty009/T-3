import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

x, y = sp.symbols('x y')
f_sym = 4*x*y - x**4 - y**4
fx = sp.diff(f_sym, x)
fy = sp.diff(f_sym, y)
fxx = sp.diff(fx, x)
fyy = sp.diff(fy, y)
fxy = sp.diff(fx, y)
# Critical points
cp = sp.solve([fx, fy], [x, y])
# Discriminant
D_expr = fxx*fyy - fxy**2
# Classification
saddle = []
maxima = []
minimum=[]
for i in cp:
    x_val, y_val = i
    # Skip complex solutions
    if sp.im(x_val) != 0 or sp.im(y_val) != 0:
        continue

    D_val = D_expr.subs({x: x_val, y: y_val}).evalf()
    fxx_val = fxx.subs({x: x_val, y: y_val}).evalf()

    if D_val < 0:
        saddle.append(i)
    elif D_val > 0 and fxx_val < 0:
        maxima.append(i)
    elif D_val>0 and fxx_val>0:
        minimum.append(i)

print("Saddle Points:", saddle)
print("Local Maxima:", maxima)
print("Local Minimum:", minimum)

# Plotting the surface
f_num = sp.lambdify((x, y), f_sym, 'numpy')#converting symbolic to numeric
x_vals = np.linspace(-2, 2, 100)
y_vals = np.linspace(-2, 2, 100)
X, Y = np.meshgrid(x_vals, y_vals)
Z = f_num(X, Y)

fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.9)

# Mark critical points  #(x,y)=pt(0,1)
for pt in saddle:
    ax.scatter(float(pt[0]), float(pt[1]), f_num(float(pt[0]), float(pt[1])), color='r', label='Saddle Point')
for pt in maxima:
    ax.scatter(float(pt[0]), float(pt[1]), f_num(float(pt[0]), float(pt[1])), color='b', label='Local Max')

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('f(x, y)')
plt.title("Surface plot of f(x, y) = 4xy - x⁴ - y⁴")
plt.legend()
plt.show()