import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from sympy import symbols,sin,cos,diff

t=symbols('t')
r=sp.Matrix([5*sp.cos(t),4*sp.sin(t)])
r_prime=r.diff(t)
tangent1 = r_prime.subs(t, np.pi/4)
tangent2 = r_prime.subs(t, np.pi)
print('First tangent:')
sp.pprint(tangent1)
print('second tangent:')
sp.pprint(tangent2)

#plotting
t_val=np.linspace(0,2*np.pi,100)
x_val=5*np.cos(t_val)
y_val=4*np.sin(t_val)

r_func=sp.lambdify(t,r,modules='numpy')
t1=np.pi/4
t2=np.pi
r1=r_func(t1)
r2=r_func(t2)
r_prime_func=sp.lambdify(t,r_prime,modules='numpy')
tangent1=r_prime_func(t1)
tangent2=r_prime_func(t2)

plt.plot(x_val,y_val)
plt.quiver(0,0,r1[0],r1[1],angles='xy',scale_units='xy',scale=1,color='r')
plt.quiver(0,0,r2[0],r2[1],angles='xy',scale_units='xy',scale=1,color='g')
plt.quiver(r1[0],r1[1],tangent1[0],tangent1[1],angles='xy',scale_units='xy',scale=1,color='r')
plt.quiver(r2[0],r2[1],tangent2[0],tangent2[1],angles='xy',scale_units='xy',scale=1,color='g')
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
plt.show()