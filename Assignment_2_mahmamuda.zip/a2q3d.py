import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

x, y = sp.symbols('x y')
T = 3 * x**2 * y
# Compute gradient
grad_T = sp.Matrix([sp.diff(T, x), sp.diff(T, y)])
# Evaluate gradient at (-1, 3/2)
grad_t0 = grad_T.subs({x: -1, y: 3/2})
print("Gradient at (-1, 3/2):", grad_t0)

# Direction vector (2D!)
v0 = sp.Matrix([-1, -1/2])
v0 = v0 / v0.norm()  # normalize it
# Compute directional derivative at point
dir_deriv_at_point = grad_t0.dot(v0)
print("Directional derivative at (-1, 3/2) in direction (-1, -1/2):", dir_deriv_at_point)

#Plotting
# General directional derivative expression
D_derivative = grad_T.dot(v0)
D_derivative_np = sp.lambdify((x, y), D_derivative, 'numpy')# Convert to numpy function
x_vals = np.linspace(-2, 0, 100)
y_vals = np.linspace(0, 2, 100)
X, Y = np.meshgrid(x_vals, y_vals)
D_vals = D_derivative_np(X, Y)

#3D surface plot
fig = plt.figure(figsize=(12, 6))
ax = fig.add_subplot(121, projection='3d')
ax.plot_surface(X, Y, D_vals, cmap='viridis')
ax.set_title('Directional Derivative Surface')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('Value')

# Contour plot
ax2 = fig.add_subplot(122)
contour = ax2.contourf(X, Y, D_vals, cmap='viridis')
plt.colorbar(contour, ax=ax2)
ax2.set_title('Directional Derivative Contour')
ax2.set_xlabel('x')
ax2.set_ylabel('y')
plt.tight_layout()
plt.show()