import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

x, y, z,r,theta= sp.symbols('x y z r theta')
P = sp.exp(x) - y**3
Q = sp.cos(y) + x**3
curl_F = sp.diff(Q, x) - sp.diff(P, y) # curl F = dQ/dx - dP/dy
# Unit circle area integral so x=1*cos(theta) and y=sin(theta)
dA = r
integral = sp.integrate(sp.integrate(curl_F.subs({x: r*sp.cos(theta), y: r*sp.sin(theta)}) * dA, (r, 0, 1)), (theta, 0, 2*sp.pi))
print("(a) Work done by the force field:", integral)  
# ---------------- Visualization ----------------
P_func = sp.lambdify((x, y), P, 'numpy')
Q_func = sp.lambdify((x, y), Q, 'numpy')
X, Y = np.meshgrid(np.linspace(-1.5, 1.5, 25), np.linspace(-1.5, 1.5, 25))
U = P_func(X, Y)
V = Q_func(X, Y)
plt.figure(figsize=(8, 8))
# Plot vector field using quiver
plt.quiver(X, Y, U, V, color='blue', alpha=0.6, label='Vector field F')
# Plot unit circle boundary (path C)
theta_vals = np.linspace(0, 2*np.pi, 200)
circle_x = np.cos(theta_vals)
circle_y = np.sin(theta_vals)
plt.plot(circle_x, circle_y, 'r--', linewidth=2, label='Boundary curve C (unit circle)')
# Add arrows along the boundary to show orientation
arrow_idx = np.linspace(0, len(theta_vals)-2, 8).astype(int)
for i in arrow_idx:
    plt.annotate('', xy=(circle_x[i+1], circle_y[i+1]), xytext=(circle_x[i], circle_y[i]),
                 arrowprops=dict(arrowstyle='->', color='black'))

plt.title('Vector Field and Unit Circle Boundary')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('equal')
plt.legend()
plt.grid(True)
plt.show()