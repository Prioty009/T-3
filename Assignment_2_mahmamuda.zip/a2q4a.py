import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-8, 8, 400)
y = np.linspace(-8, 8, 400)
X, Y = np.meshgrid(x, y)
levels = [1, 4, 9, 16, 25, 36]

# i)
Z1 = 4 * X**2 + Y**2
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
cont1 = plt.contour(X, Y, Z1, levels=levels, cmap='viridis')
plt.clabel(cont1, inline=True, fontsize=8)  # Show level values on curves
plt.colorbar(cont1)
plt.title(r'Contour Plot of $f(x,y)=4x^2 + y^2$')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('equal')

# ii) f(x, y, z) = z^2 - x^2 - y^2 → x^2 + y^2 = z^2 - k (fix z^2)
plt.subplot(1, 2, 2)
z_fixed = 7  # Let's fix z = 7 ⇒ z^2 = 49
z2_value = z_fixed**2
# Plot level curves for each k
for k in levels:
    rhs = z2_value - k
    if rhs > 0:
        radius = np.sqrt(rhs)# Circle: x^2 + y^2 = r^2
        Z2 = X**2 + Y**2
        cs = plt.contour(X, Y, Z2, levels=[rhs], colors='black')#cs=contour surface
        plt.clabel(cs, fmt={rhs: f'k={k}'}, fontsize=8)

plt.title(r'Level Curves of $f(x,y,z) = z^2 - x^2 - y^2$ (with $z=7$)')
plt.xlabel('x')
plt.ylabel('y')
plt.axis('equal')
plt.grid(True)
plt.tight_layout()
plt.show()