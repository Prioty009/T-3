import sympy as sp
from sympy import symbols,diff,sin,cos

x, y = sp.symbols('x y')
f = y**2 * sp.cos(x - y)
# Compute partial derivatives
fx = sp.diff(f, x)
fy = sp.diff(f, y)
fxx = sp.diff(fx, x)
fyy = sp.diff(fy, y)
fxy = sp.diff(fx, y)
fyx = sp.diff(fy, x)

print("\nSecond derivatives:")
print("f_xx =")
sp.pprint(fxx)
print("\nf_yy =")
sp.pprint(fyy)

laplacian = sp.simplify(fxx + fyy)
print("\nLaplacian f_xx + f_yy =")
sp.pprint(laplacian)

# Check Laplace's equation
if laplacian == 0:
    print("\nf satisfies Laplace's equation.")
else:
    print("\nf does not satisfy Laplace's equation.")

# Check Cauchy-Riemann (only makes sense if f is complex, still we check formally)
u = f
v = 0  # Since f is purely real
ux = sp.diff(u, x)
uy = sp.diff(u, y)
vx = sp.diff(v, x)
vy = sp.diff(v, y)

print("\nCauchy-Riemann equations check:")
cr1 = sp.simplify(ux - vy)
cr2 = sp.simplify(uy + vx)

if cr1 == 0 and cr2 == 0:
    print("Cauchy-Riemann equations are satisfied.")
else:
    print("Cauchy-Riemann equations are not satisfied.")
#part 3
print("\nf_xy =")
sp.pprint(fxy)
print("\nf_yx =")
sp.pprint(fyx)

if sp.simplify(fxy - fyx) == 0:
    print("\nMixed partial derivatives are equal: f_xy = f_yx")
else:
    print("\nMixed partial derivatives are not equal.")