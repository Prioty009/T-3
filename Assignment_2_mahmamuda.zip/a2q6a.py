import sympy as sp #need verificatin
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from scipy.integrate import tplquad, dblquad

x, y, z, r, theta = sp.symbols('x y z r theta')
# (a) Triple Integral
f1 = lambda z, y, x: x * np.exp(-y) * np.cos(z)
sol1 = tplquad(f1, 0, 1, lambda x: 0, lambda x: 1 - x**2, lambda x, y: 3, lambda x, y: 4 - x**2 - y**2)[0]
print("Value of the first integral (numerical):", sol1)
# (b) Double Integral
f2 = lambda y, x: (x * y) / np.sqrt(x**2 + y**2 + 1)
sol2 = dblquad(f2, 0, 1, lambda x: 0, lambda x: 1)[0]
print("Value of the second integral (numerical):", sol2)
# ------------------ Visualization ------------------
fig = plt.figure(figsize=(12, 5))
ax1 = fig.add_subplot(121, projection='3d')
X = np.linspace(0, 1, 50)
Y = np.linspace(0, 1, 50)
X, Y = np.meshgrid(X, Y)
Z_upper = 4 - X**2 - Y**2
Z_lower = 3
mask = Y <= 1 - X**2# Make sure we restrict Y to be <= 1 - X^2
X_masked = np.ma.masked_where(~mask, X)#You create a valid domain region defined by y≤1−x^2, and mask out (hide) all points outside this region from X and Y.
Y_masked = np.ma.masked_where(~mask, Y)
Z_val = X_masked * np.exp(-Y_masked) * np.cos(Z_lower)  # Just show integrand at z=3
surf = ax1.plot_surface(X_masked, Y_masked, Z_val, cmap='viridis', edgecolor='none')
ax1.set_title("Integrand of Triple Integral at z=3")
ax1.set_xlabel("x")
ax1.set_ylabel("y")
ax1.set_zlabel("f(x,y,3)")
fig.colorbar(surf, ax=ax1, shrink=0.5)
# 2nd subplot: Double integral surface
ax2 = fig.add_subplot(122, projection='3d')
X2 = np.linspace(0, 1, 50)
Y2 = np.linspace(0, 1, 50)
X2, Y2 = np.meshgrid(X2, Y2)
Z2 = (X2 * Y2) / np.sqrt(X2**2 + Y2**2 + 1)
surf2 = ax2.plot_surface(X2, Y2, Z2, cmap='plasma', edgecolor='none')
ax2.set_title("Integrand of Double Integral")
ax2.set_xlabel("x")
ax2.set_ylabel("y")
ax2.set_zlabel("f(x,y)")
fig.colorbar(surf2, ax=ax2, shrink=0.5)
plt.tight_layout()
plt.show()